package com.ben10mod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;

public class CalibrationResinItem extends Item {
    public CalibrationResinItem() { super(new Item.Properties().maxStackSize(16).group(ItemGroup.MATERIALS)); }
    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, PlayerEntity player, Hand hand) {
        ItemStack food = player.getHeldItem(hand);
        ItemStack watch = OmnitrixItem.findHeld(player);
        if (!world.isRemote && !watch.isEmpty()) {
            PowerSystem.initialize(watch);
            watch.getOrCreateTag().putInt("Mastery", Math.min(100, PowerSystem.mastery(watch) + 25));
            if (!player.abilities.isCreativeMode) food.shrink(1);
            player.sendMessage(new StringTextComponent("Resina aplicada: maestria " + PowerSystem.mastery(watch) + "%"), player.getUniqueID());
        } else if (!world.isRemote) {
            player.sendMessage(new StringTextComponent("Sostiene un Omnitrix para usar la resina"), player.getUniqueID());
        }
        return ActionResult.resultSuccess(food);
    }
}
