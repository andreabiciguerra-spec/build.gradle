package com.ben10mod;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.potion.Effect;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.item.ItemStack;
import java.util.List;

public final class PowerSystem {
    public static final String[] ALIENS = {"Heatblast", "Wildmutt", "Diamondhead", "XLR8", "Grey Matter", "Four Arms", "Stinkfly", "Ripjaws", "Upgrade", "Ghostfreak"};
    public static final String[][] POWERS = {
            {"Llamarada", "Inmunidad al fuego", "Impulso solar", "Explosión térmica", "Salto de magma"},
            {"Rastreo", "Garras", "Olfato agudo", "Embestida", "Sentidos nocturnos"},
            {"Armadura cristalina", "Golpe de diamante", "Piel reforzada", "Onda de esquirlas", "Salto de cristal"},
            {"Aceleración", "Reflejos", "Ráfaga de golpes", "Carrera veloz", "Agilidad"},
            {"Mente brillante", "Visión nocturna", "Manos ágiles", "Salto ligero", "Concentración"},
            {"Fuerza titánica", "Piel resistente", "Salto sísmico", "Golpe doble", "Empuje"},
            {"Planeo", "Aguijón", "Nube tóxica", "Vuelo ligero", "Visión aérea"},
            {"Respiración acuática", "Nado veloz", "Fuerza marina", "Pulso acuático", "Adaptación"},
            {"Mejora tecnológica", "Blindaje", "Sobrecarga", "Camuflaje", "Aceleración"},
            {"Invisibilidad", "Fase espectral", "Terror", "Caída lenta", "Visión espectral"}
    };
    private PowerSystem() {}

    public static void initialize(ItemStack stack) {
        if (!stack.hasTag()) {
            stack.getOrCreateTag().putInt("Energy", 100);
            stack.getOrCreateTag().putInt("Mastery", 0);
            stack.getOrCreateTag().putInt("Alien", 0);
            stack.getOrCreateTag().putInt("Power", 0);
        }
        if (!stack.getOrCreateTag().contains("Energy")) stack.getOrCreateTag().putInt("Energy", 100);
        if (!stack.getOrCreateTag().contains("Mastery")) stack.getOrCreateTag().putInt("Mastery", 0);
    }

    public static boolean isCalibrated(ItemStack stack) {
        return OmnitrixItem.isOmnitrix(stack) && (stack.getOrCreateTag().getBoolean("Calibrated") || OmnitrixItem.isSupreme(stack));
    }
    public static int energy(ItemStack stack) { initialize(stack); return stack.getOrCreateTag().getInt("Energy"); }
    public static int mastery(ItemStack stack) { initialize(stack); return stack.getOrCreateTag().getInt("Mastery"); }
    public static int alien(ItemStack stack) { initialize(stack); return Math.floorMod(stack.getOrCreateTag().getInt("Alien"), ALIENS.length); }
    public static int power(ItemStack stack) { initialize(stack); return Math.floorMod(stack.getOrCreateTag().getInt("Power"), 5); }
    public static String alienName(ItemStack stack) { return ALIENS[alien(stack)]; }
    public static String powerName(ItemStack stack) { return POWERS[alien(stack)][power(stack)]; }
    public static void cycleAlien(ItemStack stack) { initialize(stack); stack.getOrCreateTag().putInt("Alien", (alien(stack) + 1) % ALIENS.length); }
    public static void cyclePower(ItemStack stack) { initialize(stack); stack.getOrCreateTag().putInt("Power", (power(stack) + 1) % 5); }

    public static void toggleTransform(PlayerEntity player, ItemStack stack) {
        initialize(stack);
        if (stack.getOrCreateTag().getBoolean("Transformed")) {
            stack.getOrCreateTag().putBoolean("Transformed", false);
            player.sendMessage(new StringTextComponent("Has vuelto a tu forma normal"), player.getUniqueID());
            return;
        }
        if (energy(stack) < 10 && !stack.getOrCreateTag().getBoolean("MasterControl")) {
            player.sendMessage(new StringTextComponent("No hay energia suficiente"), player.getUniqueID());
            return;
        }
        stack.getOrCreateTag().putBoolean("Transformed", true);
        stack.getOrCreateTag().putInt("Energy", Math.max(0, energy(stack) - 5));
        player.sendMessage(new StringTextComponent("Transformacion: " + alienName(stack)), player.getUniqueID());
    }

    public static void activatePower(PlayerEntity player, ItemStack stack) {
        initialize(stack);
        boolean master = stack.getOrCreateTag().getBoolean("MasterControl");
        int cost = OmnitrixItem.isSupreme(stack) ? 12 : 8;
        boolean alreadyTransformed = stack.getOrCreateTag().getBoolean("Transformed");
        int required = cost + (alreadyTransformed ? 0 : 5);
        if (!master && energy(stack) < required) {
            player.sendMessage(new StringTextComponent("Energia insuficiente; espera a que se recargue"), player.getUniqueID());
            return;
        }
        if (!alreadyTransformed) toggleTransform(player, stack);
        if (!stack.getOrCreateTag().getBoolean("Transformed")) return;
        if (!master) stack.getOrCreateTag().putInt("Energy", Math.max(0, energy(stack) - cost));
        int a = alien(stack), p = power(stack);
        int amp = OmnitrixItem.isSupreme(stack) ? 2 : (PowerSystem.isCalibrated(stack) ? 1 : 0);
        apply(player, a, p, amp);
        stack.getOrCreateTag().putInt("Mastery", Math.min(100, mastery(stack) + 2));
        player.sendMessage(new StringTextComponent(POWERS[a][p] + " activado"), player.getUniqueID());
    }

    private static void effect(PlayerEntity player, Effect effect, int amp, int seconds) {
        player.addPotionEffect(new EffectInstance(effect, seconds * 20, amp, false, true));
    }
    private static void burst(PlayerEntity player, float radius, float damage, boolean ignite) {
        AxisAlignedBB box = player.getBoundingBox().grow(radius);
        List<LivingEntity> targets = player.world.getEntitiesWithinAABB(LivingEntity.class, box,
                entity -> entity != player && entity.isAlive() && !entity.isSpectator());
        for (LivingEntity target : targets) {
            target.attackEntityFrom(DamageSource.causePlayerDamage(player), damage);
            if (ignite) target.setFire(3);
            double dx = target.getPosX() - player.getPosX();
            double dz = target.getPosZ() - player.getPosZ();
            target.addVelocity(dx * 0.18D, 0.25D, dz * 0.18D);
        }
    }
    private static void apply(PlayerEntity player, int alien, int power, int amp) {
        int seconds = 8 + amp * 4;
        switch (alien) {
            case 0:
                if (power == 0 || power == 3) burst(player, power == 3 ? 4.0F : 2.5F, 5 + amp * 2, true);
                else if (power == 1) effect(player, Effects.FIRE_RESISTANCE, 0, seconds + 10);
                else if (power == 2) effect(player, Effects.STRENGTH, amp, seconds);
                else effect(player, Effects.JUMP_BOOST, 1 + amp, seconds);
                break;
            case 1:
                if (power == 0 || power == 2 || power == 4) effect(player, power == 4 ? Effects.NIGHT_VISION : Effects.SPEED, amp + (power == 0 ? 1 : 0), seconds + 8);
                else if (power == 1) burst(player, 2.5F, 6 + amp, false);
                else { effect(player, Effects.SPEED, 1 + amp, seconds); burst(player, 3.0F, 4 + amp, false); }
                break;
            case 2:
                if (power == 0 || power == 2) effect(player, Effects.RESISTANCE, 1 + amp, seconds);
                else if (power == 1 || power == 3) burst(player, power == 3 ? 4.0F : 2.5F, 6 + amp * 2, false);
                else effect(player, Effects.JUMP_BOOST, 1 + amp, seconds);
                break;
            case 3:
                if (power == 0 || power == 3 || power == 4) effect(player, Effects.SPEED, 2 + amp, seconds);
                else if (power == 1) effect(player, Effects.HASTE, 1 + amp, seconds);
                else { effect(player, Effects.SPEED, 1 + amp, 5); burst(player, 2.0F, 4 + amp, false); }
                break;
            case 4:
                if (power == 0 || power == 4) effect(player, Effects.HASTE, 1 + amp, seconds);
                else if (power == 1) effect(player, Effects.NIGHT_VISION, 0, seconds + 8);
                else if (power == 2) effect(player, Effects.SPEED, amp + 1, seconds);
                else { effect(player, Effects.JUMP_BOOST, 1 + amp, seconds); effect(player, Effects.RESISTANCE, amp, seconds); }
                break;
            case 5:
                if (power == 0 || power == 3) effect(player, Effects.STRENGTH, 2 + amp, seconds);
                else if (power == 1) effect(player, Effects.RESISTANCE, 1 + amp, seconds);
                else if (power == 2) { effect(player, Effects.JUMP_BOOST, 2 + amp, seconds); burst(player, 3.5F, 7 + amp * 2, false); }
                else burst(player, 3.0F, 7 + amp * 2, false);
                break;
            case 6:
                if (power == 0 || power == 3) effect(player, Effects.SLOW_FALLING, 0, seconds + 5);
                else if (power == 1) burst(player, 2.0F, 5 + amp, false);
                else if (power == 2) { burst(player, 4.0F, 3 + amp, false); for (LivingEntity e : player.world.getEntitiesWithinAABB(LivingEntity.class, player.getBoundingBox().grow(4.0D), q -> q != player)) e.addPotionEffect(new EffectInstance(Effects.POISON, 80, amp)); }
                else effect(player, Effects.NIGHT_VISION, 0, seconds + 8);
                break;
            case 7:
                if (power == 0) effect(player, Effects.WATER_BREATHING, 0, seconds + 10);
                else if (power == 1) effect(player, Effects.DOLPHINS_GRACE, 1 + amp, seconds);
                else if (power == 2) effect(player, Effects.STRENGTH, 1 + amp, seconds);
                else if (power == 3) burst(player, 4.0F, 5 + amp, false);
                else effect(player, Effects.RESISTANCE, amp, seconds);
                break;
            case 8:
                if (power == 0 || power == 2) effect(player, Effects.HASTE, 1 + amp, seconds);
                else if (power == 1) effect(player, Effects.RESISTANCE, 1 + amp, seconds);
                else if (power == 3) effect(player, Effects.INVISIBILITY, 0, seconds);
                else effect(player, Effects.SPEED, 1 + amp, seconds);
                break;
            default:
                if (power == 0 || power == 1) effect(player, Effects.INVISIBILITY, 0, seconds);
                else if (power == 2) { burst(player, 3.5F, 4 + amp, false); for (LivingEntity e : player.world.getEntitiesWithinAABB(LivingEntity.class, player.getBoundingBox().grow(3.5D), q -> q != player)) e.addPotionEffect(new EffectInstance(Effects.WEAKNESS, 100, amp)); }
                else if (power == 3) effect(player, Effects.SLOW_FALLING, 0, seconds + 5);
                else effect(player, Effects.NIGHT_VISION, 0, seconds + 8);
        }
    }
}
