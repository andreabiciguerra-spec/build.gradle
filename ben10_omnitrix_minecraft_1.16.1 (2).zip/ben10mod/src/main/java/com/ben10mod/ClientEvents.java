package com.ben10mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.client.util.InputMappings;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraft.util.text.StringTextComponent;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = Ben10Mod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClientEvents {
    private static KeyBinding ability, nextAlien, nextPower, transform;
    @SubscribeEvent
    public static void setup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            ability = key("key.ben10mod.ability", GLFW.GLFW_KEY_R);
            nextAlien = key("key.ben10mod.next_alien", GLFW.GLFW_KEY_B);
            nextPower = key("key.ben10mod.next_power", GLFW.GLFW_KEY_V);
            transform = key("key.ben10mod.transform", GLFW.GLFW_KEY_T);
        });
    }
    private static KeyBinding key(String name, int code) {
        KeyBinding binding = new KeyBinding(name, KeyConflictContext.IN_GAME, InputMappings.Type.KEYSYM, code, "key.categories.ben10mod");
        ClientRegistry.registerKeyBinding(binding);
        return binding;
    }

    @Mod.EventBusSubscriber(modid = Ben10Mod.MODID, value = Dist.CLIENT)
    public static class KeyEvents {
        @SubscribeEvent
        public static void onKey(InputEvent.KeyInputEvent event) {
            if (ability != null && ability.isPressed()) Ben10Mod.CHANNEL.sendToServer(new ActionPacket(0));
            if (nextAlien != null && nextAlien.isPressed()) Ben10Mod.CHANNEL.sendToServer(new ActionPacket(1));
            if (nextPower != null && nextPower.isPressed()) Ben10Mod.CHANNEL.sendToServer(new ActionPacket(2));
            if (transform != null && transform.isPressed()) Ben10Mod.CHANNEL.sendToServer(new ActionPacket(3));
        }

        @SubscribeEvent
        public static void overlay(RenderGameOverlayEvent.Post event) {
            if (event.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return;
            net.minecraft.item.ItemStack stack = OmnitrixItem.findHeld(mc.player);
            if (stack.isEmpty()) return;
            int x = 8, y = event.getWindow().getScaledHeight() - 42;
            int energy = PowerSystem.energy(stack), mastery = PowerSystem.mastery(stack);
            mc.fontRenderer.drawStringWithShadow("OMNITRIX | " + PowerSystem.alienName(stack) + " - " + PowerSystem.powerName(stack), x, y, PowerSystem.isCalibrated(stack) ? 0x55AAFF : 0xFF5555);
            mc.getTextureManager();
            net.minecraft.client.gui.AbstractGui.fill(x, y + 12, x + 104, y + 18, 0xAA222222);
            net.minecraft.client.gui.AbstractGui.fill(x, y + 12, x + energy, y + 18, PowerSystem.isCalibrated(stack) ? 0xFF3399FF : 0xFFFF3333);
            mc.fontRenderer.drawStringWithShadow("Energia " + energy + "%  |  Maestria " + mastery + "%", x, y + 21, 0xFFFFFF);
            if (stack.getOrCreateTag().getBoolean("MasterControl")) mc.fontRenderer.drawStringWithShadow("CONTROL MAESTRO", x + 150, y + 21, 0xFFFFD700);
        }
    }
}
