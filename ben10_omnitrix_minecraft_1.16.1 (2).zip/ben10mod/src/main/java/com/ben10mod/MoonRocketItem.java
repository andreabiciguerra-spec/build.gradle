package com.ben10mod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.RegistryKey;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.server.ServerWorld;

public class MoonRocketItem extends Item {
    private static final RegistryKey<World> MOON = RegistryKey.getOrCreateKey(Registry.WORLD_KEY, new ResourceLocation(Ben10Mod.MODID, "luna"));
    private static final RegistryKey<World> OVERWORLD = RegistryKey.getOrCreateKey(Registry.WORLD_KEY, new ResourceLocation("minecraft", "overworld"));
    public MoonRocketItem() { super(new Item.Properties().maxStackSize(1).group(ItemGroup.TRANSPORTATION)); }
    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (!world.isRemote && player instanceof ServerPlayerEntity) {
            ServerPlayerEntity serverPlayer = (ServerPlayerEntity) player;
            ServerWorld target = world.getServer().getWorld(world.getDimensionKey().equals(MOON) ? OVERWORLD : MOON);
            if (target == null) {
                player.sendMessage(new StringTextComponent("No se encontro el destino lunar. Reinicia el mundo con el datapack del mod cargado."), player.getUniqueID());
            } else if (player.canChangeDimensions()) {
                serverPlayer.changeDimension(target);
                if (!player.abilities.isCreativeMode) stack.shrink(1);
            }
        }
        return ActionResult.resultSuccess(stack);
    }
}
