package com.ben10mod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;

public class OmnitrixItem extends Item {
    public enum Tier { PROTOTYPE, CALIBRATED, SUPREME }
    private final Tier tier;

    public OmnitrixItem(Tier tier) {
        super(new Item.Properties().maxStackSize(1).group(ItemGroup.TOOLS));
        this.tier = tier;
    }

    public Tier getTier() { return tier; }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (!world.isRemote) {
            if (player.isSneaking()) {
                if (player.getHeldItemOffhand().getItem() == Ben10Mod.MASTER_KEY.get() && PowerSystem.isCalibrated(stack)) {
                    stack.getOrCreateTag().putBoolean("MasterControl", true);
                    player.sendMessage(new StringTextComponent("Control maestro desbloqueado"), player.getUniqueID());
                } else {
                    PowerSystem.cycleAlien(stack);
                    player.sendMessage(new StringTextComponent("Alien: " + PowerSystem.alienName(stack)), player.getUniqueID());
                }
            } else {
                PowerSystem.activatePower(player, stack);
            }
        }
        return ActionResult.resultSuccess(stack);
    }

    public static boolean isOmnitrix(ItemStack stack) {
        return stack.getItem() instanceof OmnitrixItem;
    }

    public static ItemStack findHeld(PlayerEntity player) {
        if (isOmnitrix(player.getHeldItemMainhand())) return player.getHeldItemMainhand();
        if (isOmnitrix(player.getHeldItemOffhand())) return player.getHeldItemOffhand();
        return ItemStack.EMPTY;
    }

    public static void tickPlayer(PlayerEntity player) {
        ItemStack stack = findHeld(player);
        if (stack.isEmpty()) return;
        PowerSystem.initialize(stack);
        if (!PowerSystem.isCalibrated(stack) && (player.experienceLevel >= 10 || stack.getOrCreateTag().getInt("Mastery") >= 100)) {
            stack.getOrCreateTag().putBoolean("Calibrated", true);
            if (stack.getItem() == Ben10Mod.OMNITRIX.get()) {
                ItemStack blue = new ItemStack(Ben10Mod.CALIBRATED_OMNITRIX.get());
                blue.setTag(stack.getTag().copy());
                player.setHeldItem(player.getHeldItemMainhand() == stack ? Hand.MAIN_HAND : Hand.OFF_HAND, blue);
                stack = blue;
            }
            player.sendMessage(new StringTextComponent("Omnitrix calibrado: energia estabilizada"), player.getUniqueID());
        }
        if (stack.getOrCreateTag().getBoolean("Transformed")) {
            int energy = stack.getOrCreateTag().getInt("Energy");
            if (energy <= 0) {
                stack.getOrCreateTag().putBoolean("Transformed", false);
                player.sendMessage(new StringTextComponent("Energia agotada: transformacion finalizada"), player.getUniqueID());
            } else if (!stack.getOrCreateTag().getBoolean("MasterControl")) {
                stack.getOrCreateTag().putInt("Energy", Math.max(0, energy - (isSupreme(stack) ? 2 : 1)));
            }
        } else {
            int max = 100;
            int energy = stack.getOrCreateTag().getInt("Energy");
            stack.getOrCreateTag().putInt("Energy", Math.min(max, energy + (PowerSystem.isCalibrated(stack) ? 5 : 2)));
        }
    }

    public static boolean isSupreme(ItemStack stack) { return stack.getItem() == Ben10Mod.SUPREME_OMNITRIX.get(); }
}
