package com.ben10mod;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.attributes.Attributes;
import net.minecraft.entity.monster.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;

public class AlbedoBeaconItem extends Item {
    public AlbedoBeaconItem() { super(new Item.Properties().maxStackSize(1).group(ItemGroup.TOOLS)); }
    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (!world.isRemote) {
            ZombieEntity albedo = EntityType.ZOMBIE.create(world);
            if (albedo != null) {
                albedo.setLocationAndAngles(player.getPosX() + 3, player.getPosY(), player.getPosZ() + 3, player.rotationYaw, 0);
                albedo.setCustomName(new StringTextComponent("Albedo - Omnitrix Supremo"));
                albedo.setCustomNameVisible(true);
                albedo.enablePersistence();
                albedo.getAttribute(Attributes.field_233818_a_).setBaseValue(100.0D);
                albedo.getAttribute(Attributes.field_233823_f_).setBaseValue(12.0D);
                albedo.getAttribute(Attributes.field_233821_d_).setBaseValue(0.34D);
                albedo.setHealth(100.0F);
                albedo.setItemStackToSlot(EquipmentSlotType.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
                world.addEntity(albedo);
                if (!player.abilities.isCreativeMode) stack.shrink(1);
                player.sendMessage(new StringTextComponent("Albedo ha llegado. El aspecto usa el modelo de un zombi vanilla."), player.getUniqueID());
            }
        }
        return ActionResult.resultSuccess(stack);
    }
}
