package com.ben10mod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.network.NetworkEvent;
import java.util.function.Supplier;

public class ActionPacket {
    private final int action;
    public ActionPacket(int action) { this.action = action; }
    public static void encode(ActionPacket msg, PacketBuffer buffer) { buffer.writeVarInt(msg.action); }
    public static ActionPacket decode(PacketBuffer buffer) { return new ActionPacket(buffer.readVarInt()); }
    public static void handle(ActionPacket msg, Supplier<NetworkEvent.Context> context) {
        NetworkEvent.Context ctx = context.get();
        ctx.enqueueWork(() -> {
            PlayerEntity player = ctx.getSender();
            if (player == null) return;
            ItemStack stack = OmnitrixItem.findHeld(player);
            if (stack.isEmpty()) return;
            if (msg.action == 0) PowerSystem.activatePower(player, stack);
            else if (msg.action == 1) PowerSystem.cycleAlien(stack);
            else if (msg.action == 2) PowerSystem.cyclePower(stack);
            else if (msg.action == 3) PowerSystem.toggleTransform(player, stack);
        });
        ctx.setPacketHandled(true);
    }
}
