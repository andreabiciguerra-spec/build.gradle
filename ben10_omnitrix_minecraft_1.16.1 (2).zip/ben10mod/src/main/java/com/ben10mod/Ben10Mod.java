package com.ben10mod;

import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.fml.network.NetworkRegistry;
import net.minecraftforge.fml.network.simple.SimpleChannel;

@Mod(Ben10Mod.MODID)
public class Ben10Mod {
    public static final String MODID = "ben10mod";
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    public static final RegistryObject<Item> OMNITRIX = ITEMS.register("omnitrix_prototype",
            () -> new OmnitrixItem(OmnitrixItem.Tier.PROTOTYPE));
    public static final RegistryObject<Item> CALIBRATED_OMNITRIX = ITEMS.register("omnitrix_calibrated",
            () -> new OmnitrixItem(OmnitrixItem.Tier.CALIBRATED));
    public static final RegistryObject<Item> SUPREME_OMNITRIX = ITEMS.register("omnitrix_supreme",
            () -> new OmnitrixItem(OmnitrixItem.Tier.SUPREME));
    public static final RegistryObject<Item> MASTER_KEY = ITEMS.register("master_key",
            () -> new Item(new Item.Properties().maxStackSize(1).group(ItemGroup.TOOLS)));
    public static final RegistryObject<Item> RESIN = ITEMS.register("calibration_resin", CalibrationResinItem::new);
    public static final RegistryObject<Item> NITRITE = ITEMS.register("nitrite_crystal",
            () -> new Item(new Item.Properties().group(ItemGroup.MATERIALS)));
    public static final RegistryObject<Item> ALBEDO_BEACON = ITEMS.register("albedo_beacon", AlbedoBeaconItem::new);
    public static final RegistryObject<Item> MOON_ROCKET = ITEMS.register("moon_rocket", MoonRocketItem::new);

    public Ben10Mod() {
        ITEMS.register(FMLJavaModLoadingContext.get().getModEventBus());
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::setup);
        MinecraftForge.EVENT_BUS.register(new CommonEvents());
    }

    private void setup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> CHANNEL.registerMessage(0, ActionPacket.class,
                ActionPacket::encode, ActionPacket::decode, ActionPacket::handle));
    }

    public static class CommonEvents {
        @SubscribeEvent
        public void onPlayerTick(TickEvent.PlayerTickEvent event) {
            if (event.phase != TickEvent.Phase.END || event.player.world.isRemote || event.player.ticksExisted % 20 != 0) return;
            OmnitrixItem.tickPlayer(event.player);
        }
    }
}
