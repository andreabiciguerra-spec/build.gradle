# Ben 10: Omnitrix Prototype (Minecraft Java 1.16.1)

Fan-made Forge source project. This is a playable first prototype, not an official Ben 10 product.

## What is included

- Forge 1.16.1 / 32.0.108 project source.
- Prototype Omnitrix, automatic blue calibration at player level 10 or full mastery, calibrated energy recharge and an energy meter.
- Ten classic alien selections, five named power slots per alien, and enhanced effects on the Supreme Omnitrix.
- Mastery increases as powers are used; crafted calibration resin adds mastery. The Supreme Omnitrix recipe accepts prototype or calibrated versions.
- Master Control can be unlocked by sneaking with the Omnitrix while holding the crafted key in the off hand. It prevents energy drain.
- A craftable Albedo beacon spawns a strong named zombie as a gameplay stand-in.
- A craftable rocket attempts travel to the included flat moon dimension and back.
- Small custom item icons and Spanish/English item labels.

## Controls

Hold an Omnitrix in either hand. Default keys: R activate current power, B select the next alien, V select the next power, T transform or return. Sneak + right-click cycles aliens. Hold the Master Control Key in the off hand and sneak + right-click to unlock Master Control.

The energy meter and mastery percentage appear at the lower left while the Omnitrix is held. When energy reaches zero, transformation ends; energy recharges while inactive. Reaching level 10 or 100% mastery changes the prototype into its blue calibrated item.

## Build and install

1. Install a Java 8 JDK and a compatible Gradle installation.
2. Open this folder in an IDE such as IntelliJ IDEA and let Gradle resolve Forge dependencies (the first build needs internet access).
3. Run the Gradle `build` task. The mod jar is created in `build/libs`.
4. Install Forge 1.16.1 for Minecraft, then place the built jar in the Minecraft `mods` folder.
5. Create a new world or restart the world after installing, so the moon dimension data is loaded.

This workspace could not compile or launch Minecraft because Java/Gradle are not installed here. Build and test the project in a Java 8 Forge development environment before sharing it.

## Prototype limits

The five powers per alien are gameplay effects, not custom attack animations. Player models do not turn into 3D alien models; the HUD shows the selected form. Albedo uses a strengthened vanilla zombie model and is summoned with the beacon where the player uses it, rather than automatically spawning by villages. Nitrite is currently a crafting material rather than a naturally generated cave ore. The moon is a small flat test dimension, not a full lunar world; no Azmuth NPC, custom spacecraft model, dinosaur transformation, or series-accurate voice/animation assets are included.
